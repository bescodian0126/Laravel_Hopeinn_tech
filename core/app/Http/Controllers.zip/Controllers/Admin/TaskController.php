<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Task;
use App\Models\TaskQuiz;
use App\Models\Answer;
use Illuminate\Http\Request;

class TaskController extends Controller
{
    //
    public function tasks(){
        $pageTitle = "Tasks";
        $tasks = Task::with('taskQuizzes.answers')->orderBy("created_at","desc")->get();
        return view('admin.task.index', compact('pageTitle', 'tasks'));
    }

    

    public function task(Request $request){
        $pageTitle = "Add Questions";
        $data = $request->all();
        $task = Task::with('taskQuizzes.answers')->where('id', $data['id'])->orderBy("created_at","desc")->get()->first();
        // print_r($task); exit;
        return view('admin.task.add_questions', compact('pageTitle', 'task'));
    }

    public function status($id){
        return Task::changeStatus( $id);
    }

    public function create_question(Request $request){
        $this->validate($request, [
            'id'                    => 'required',
            'new_question_area'     => 'required'
        ]);

        $task_id = $request->id;
        $question = $request->new_question_area;

        $quiz = new TaskQuiz();
        $quiz->task_id = $task_id;
        $quiz->question = $question;
        $quiz->save();
        $notify[] = ['success', 'Question saved successfully'];
        return back()->withNotify($notify);
    }

    public function edit_question(Request $request){  
        $this->validate($request, [
            'id'                    => 'required',
            'edit_question_area'     => 'required'
        ]);

        $question_id = $request->id;
        $question = $request->edit_question_area;

        $quiz = TaskQuiz::where('id', $question_id)->first();
        $quiz->question = $question;
        $quiz->save();
        $notify[] = ['success','Question changed successfully'];
        return back()->withNotify($notify);
    }

    public function delete_question(Request $request){
        $this->validate($request, [
            'id' => 'required'
        ]);
        $question_id = $request->id;

        Answer::where('question_id', $question_id)->delete();

        $quiz = TaskQuiz::where('id', $question_id)->first();
        $quiz->delete();
        $notify[] = ['success','Delete question successfully'];
        return back()->withNotify($notify);
    }

    public function taskSave(Request $request){
        $this->validate($request, [
            'name'              => 'required',
            'required_energy'   => 'required|numeric|min:0', 
            'reward_energy'     => 'required|min:0|numeric',
            'description'       => 'required',
            'taskVideoFile'     => 'required|file|mimes:mp4,avi,mkv,mov,wmv,flv,webm,mpeg,mpg|max:4096',    // max 4M
        ]);

        $task_id = $request->id;

        $file = $request->file('taskVideoFile');
        $file_original_name = $file->getClientOriginalName();
        $file_name = time(). '_' . $file_original_name;
        $file_path = $file->storeAs('public/quiz_video', $file_name);
        $task = new Task();

        if ($request->id) {
            $task = Task::findOrFail($request->id);
        }

        $task->task_name = $request->name;
        $task->description = $request->description;
        $task->energy_cost = $request->required_energy;
        $task->reward = $request->reward_energy;
        $task->file_path = $file_path;
        $task->file_name = $file->getClientOriginalName();
        $task->server_file_name = $file_name;
        $task->save();
        
        $notify[] = ['success', 'Task saved successfully'];
        return back()->withNotify($notify);
    }

    public function taskUpdate(Request $request, $id){

    }

    public function add_answer(Request $request){
        $validatedData = $request->validate([
            // Define validation rules here if necessary
        ]);

        // Process the request data as needed
        $question_id = $request -> question_id;
        $answer = $request->answer;
        $true_false = $request->true_false;

        $new_answer = new Answer();
        $new_answer->question_id = $question_id;
        $new_answer->answer = $answer;
        $new_answer->true_false = $true_false;
        $new_answer->save();

        $new_answer_id = $new_answer->id;

        // Perform operations with $data

        // Return a response (e.g., JSON response)
        return response()->json(['message' => 'Answer saved successfully', 'answer_id' => $new_answer_id]);
    }

    public function edit_answer(Request $request){
        $validatedData = $request->validate([
            // Define validation rules here if necessary
        ]);

        // Process the request data as needed
        $answer_id = $request -> answer_id;
        $answer = $request->answer;
        $true_false = $request->true_false;

        $exist_answer = Answer::where('id', $answer_id)->first();

        $exist_answer->answer = $answer;
        $exist_answer->true_false = $true_false;

        $exist_answer->save();

        $new_answer_id = $exist_answer->id;

        // Perform operations with $data

        // Return a response (e.g., JSON response)
        return response()->json(['message' => 'Answer saved successfully', 'answer_id' => $new_answer_id]);
    }

    public function delete_answer(Request $request){
        $validatedData = $request->validate([
            // Define validation rules here if necessary
        ]);

        // Process the request data as needed
        $answer_id = $request -> answer_id;

        Answer::where('id', $answer_id)->delete();

        // Perform operations with $data

        // Return a response (e.g., JSON response)
        return response()->json(['message' => 'Answer saved successfully', 'answer_id' => $answer_id]);
    }
}
