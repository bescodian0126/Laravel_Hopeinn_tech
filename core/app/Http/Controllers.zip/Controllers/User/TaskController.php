<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Gateway\PaymentController;
use Illuminate\Http\Request;
use App\Models\Task;
use App\Models\TaskStatus;
use App\Models\GatewayCurrency;
use App\Models\Transaction;
use App\Constants\Status;
use Illuminate\Support\Facades\Storage;

class TaskController extends Controller
{
    //
    public function index()
    {
        $pageTitle = "Tasks";
        $user = auth()->user();
        $tasks = Task::with('taskQuizzes.answers')->orderBy("created_at", "desc")->get();
        $gateway_currency = GatewayCurrency::whereHas('method', function ($gate) {
            $gate->where('status', Status::ENABLE);
        })->with('method')->orderby('name')->get();
        return view($this->activeTemplate . 'user.task.index', compact('pageTitle', 'tasks', 'gateway_currency', 'user'));
    }
    public function start(Request $request)
    {
        $request->validate([
            'task_id' => 'required',
            'payment_method' => 'required'
        ]);

        $task_id = $request->task_id;

        $task = Task::where('status', Status::ENABLE)->findOrFail($task_id);
        $user = auth()->user();
        if ($user->balance < $task->energy_cost) {
            $notify[] = ['error', 'You\'ve no sufficient balance'];
            return back()->withNotify($notify);
        }

        if ($request->payment_method != 'balance') {
            $gate = GatewayCurrency::whereHas('method', function ($gate) {
                $gate->where('status', Status::ENABLE);
            })->find($request->payment_method);

            if (!$gate) {
                $notify[] = ['error', 'Invalid gateway'];
                return back()->withNotify($notify);
            }

            if ($gate->min_amount > $task->energy_cost || $gate->max_amount < $task->energy_cost) {
                $notify[] = ['error', 'Plan price crossed gateway limit.'];
                return back()->withNotify($notify);
            }

            $data = PaymentController::insertDeposit($gate, $task->energy_cost, $task);
            session()->put('Track', $data->trx);
            return to_route('user.deposit.confirm');
        }

        $amount = $task->energy_cost;
        $trx = getTrx();
        $transaction = new Transaction();
        $transaction->user_id = $user->id;
        $transaction->amount = $amount;
        $transaction->trx_type = '-';
        $transaction->details = 'Purchased ' . $task->name;
        $transaction->remark = 'Started Task';
        $transaction->trx = $trx;
        $transaction->post_balance = $user->balance;
        $transaction->deducted_balance = $user->deducted_balance;
        $transaction->save();

        $pageTitle = 'Task Start';

        $user_id = $user->id;
        $status = 0;
        $task_status = TaskStatus::where('user_id', $user_id)->where('task_id', $task_id)->first();
        if ($task_status == null) {
            $new_task_status = new TaskStatus();
            $new_task_status->user_id = $user_id;
            $new_task_status->task_id = $task_id;
            $new_task_status->save();
        } else{
            $status = $task_status->status;
        }

        $notify[] = ['success', ucfirst($task->name) . ' task started Successfully'];
        return view($this->activeTemplate . 'user.task.quiz', compact('pageTitle', 'task_id', 'user_id', 'status'));
    }

    public function download_video(Request $request)
    {
        
        $task_id = $request->task_id;
        $user_id = $request->user_id;

        // Fetch task information
        $task = Task::findOrFail($task_id);
        
        $filePath = $task->file_path;
        
        $fileName = $task->server_file_name;

        // Get full path to the file
        $storageFilePath = storage_path('app/' . $filePath);

        if (!file_exists($storageFilePath)) {
            return response()->json(['error' => 'File not found.'], 404);
        }

        // Read file contents and encode in base64
        $fileContent = base64_encode(file_get_contents($storageFilePath));
        $fileType = mime_content_type($storageFilePath);

        // $task_status = TaskStatus::where('user_id', $user->id)->where('task_id', $task_id)->first()->status;

        // Return JSON response with file data
        return response()->json([
            'file_content' => $fileContent,
            'file_name' => $fileName,
            'file_type' => $fileType,
            // 'task_status' => $task_status
            'task_status'=>$user_id
        ]);
    }
}
